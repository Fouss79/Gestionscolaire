package com.saas.school.dto;


import lombok.Data;

@Data
public class CategorieDepenseRequestDTO {

    private String nom;
    private Long ecoleId;
}